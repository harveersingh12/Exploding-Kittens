package ClientServer;

import Utils.Exceptions.*;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;

public class Client {
    /**
     * List of all fundamental (non-bonus) commands on the client side. These commands
     * are required for playing the game and starting it.
     */

    public enum BasicCommands implements Protocol.Command {
        CONNECT,ADD_COMPUTER,REMOVE_COMPUTER,REQUEST_GAME,PLAY_CARD,DRAW_CARD
    }

    /**
     * List of commands for bonus features. Currently, there is only the SEND command,
     * meant for one player to correspond with others (chat feature). This list, as with
     * the server commands can be extended.
     */
    public enum AdvancedCommand implements Protocol.Command {
        SEND
    }

    private Socket serverSock;
    private BufferedReader in;
    private BufferedWriter out;
    private ClientTUI view;
    private boolean readingFromServer;

    public Client(){
        view=new ClientTUI(this);
    }

    public Socket getServerSock(){
        return serverSock;
    }

    public void start(){
        try {
            createConnection();
            handleHello();
            readingFromServerThread();
            view.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates a connection to the server. Requests the IP and port to
     * connect to at the view (TUI).
     * <p>
     * The method continues to ask for an IP and port and attempts to connect
     * until a connection is established or until the user indicates to exit
     * the program.
     *
     * @throws ExitProgram if a connection is not established and the user
     *                     indicates to want to exit the program.
     * @ensures serverSock contains a valid socket connection to a server
     */
    public void createConnection() throws ExitProgram{
        clearConnection();
        while(serverSock==null){
            String host="127.0.0.1";
            //String host = String.valueOf(view.getIp());
            view.update("Enter a port on which you would like to connect.");
            int port=view.keyboardIntInput();

            // try to open a Socket to the server
            try {
                InetAddress addr=InetAddress.getByName(host);
                view.update("Attempting to connect to "+addr+":"+port+"...");
                serverSock=new Socket(addr,port);
                in=new BufferedReader(new InputStreamReader(serverSock.getInputStream()));
                out=new BufferedWriter(new OutputStreamWriter(serverSock.getOutputStream()));
            } catch (IOException e) {
                view.update("ERROR: could not create a socket on "+host+" and port "+port+".");

                //Do you want to try again? (ask user, to be implemented)
                if(false){
                    throw new ExitProgram("User indicated to exit.");
                }
            }
        }
    }

    /**
     * Resets the serverSocket and In- and OutputStreams to null.
     * <p>
     * Always make sure to close current connections via shutdown()
     * before calling this method!
     */
    public void clearConnection(){
        serverSock=null;
        in=null;
        out=null;
    }

    /**
     * Sends a message to the connected server, followed by a new line.
     * The stream is then flushed.
     *
     * @param msg the message to write to the OutputStream.
     * @throws ServerUnavailableException if IO errors occur.
     */
    public synchronized void sendMessage(String msg) throws ServerUnavailableException{
        if(out!=null){
            try {
                out.write(msg);
                out.newLine();
                out.flush();
            } catch (IOException e) {
                System.out.println(e.getMessage());
                throw new ServerUnavailableException("Could not write to server.");
            }
        } else {
            throw new ServerUnavailableException("Could not write to server.");
        }
    }

    private void readingFromServerThread(){
        if(!readingFromServer){
            readingFromServer = true;
            Thread serverReaderThread = new Thread(this::readFromServerLoop);
            serverReaderThread.start();
        }
    }

    private void readFromServerLoop(){
        try {
            while(readingFromServer){
                String line=readLineFromServer();
                if(line != null){
                    view.update(line);
                }
            }
        }catch (ServerUnavailableException e){
            e.printStackTrace();
        }
    }

    private synchronized void handleServerMessage(String message){
        view.update(message);
    }

    /**
     * Reads and returns one line from the server.
     *
     * @return the line sent by the server.
     * @throws ServerUnavailableException if IO errors occur.
     */
    public String readLineFromServer() throws ServerUnavailableException{
        if(in!=null){
            try {
                // Read and return answer from Server
                String answer=in.readLine();
                if(answer==null){
                    throw new ServerUnavailableException("Could not read from server.");
                }
                return answer;
            } catch (IOException e) {
                throw new ServerUnavailableException("Could not read from server.");
            }
        } else {
            throw new ServerUnavailableException("Could not read from server.");
        }
    }

    public static void receiveMessage(String argument){
        // view.update(argument);
    }

    /**
     * Reads and returns multiple lines from the server until the end of
     * the text is indicated using a line containing ProtocolMessages.EOT.
     *
     * @return the concatenated lines sent by the server.
     * @throws ServerUnavailableException if IO errors occur.
     */
    public String readMultipleLinesFromServer() throws ServerUnavailableException{
        if(in!=null){
            try {
                // Read and return answer from Server
                StringBuilder sb = new StringBuilder();
                for (String line=in.readLine(); line!=null; line=in.readLine()) {
                    sb.append(line+System.lineSeparator());
                }
                return sb.toString();
            } catch (IOException e) {
                throw new ServerUnavailableException("Could not read from server.");
            }
        } else {
            throw new ServerUnavailableException("Could not read from server.");
        }
    }

    /**
     * Closes the connection by closing the In- and OutputStreams, as
     * well as the serverSocket.
     */
    public void closeConnection(){
        System.out.println("Closing the connection...");
        try {
            in.close();
            out.close();
            serverSock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleHello() throws ServerUnavailableException, ProtocolException{
        try {
            view.update("Connect using the protocol message.");
            String input = view.keyboardStringInput();
            String[] splitByDelimiter = input.split("~");
            if(splitByDelimiter.length == 2)
                sendMessage(BasicCommands.CONNECT+Protocol.ARGUMENT_SEPARATOR+splitByDelimiter[1]);
            else if(splitByDelimiter.length == 3) {
                if(view.checkFlags(splitByDelimiter[2].split(","))){
                    sendMessage(BasicCommands.CONNECT+Protocol.ARGUMENT_SEPARATOR+splitByDelimiter[1]+Protocol.ARGUMENT_SEPARATOR+splitByDelimiter[2]);
                } else sendMessage(BasicCommands.CONNECT+Protocol.ARGUMENT_SEPARATOR);
            }else sendMessage(BasicCommands.CONNECT+Protocol.ARGUMENT_SEPARATOR);
//            if(!message.contains(String.valueOf(Server.BasicCommands.HELLO))&&!message.contains("U-ParkHotel")){
//                throw new ProtocolException("Hello did not go good");
//            } else {
            //view.update(readLineFromServer());
            //}
        } catch (Exception e) {
            System.out.println("Error: "+e);
        }
    }

    public void addComputer() throws ServerUnavailableException {
        sendMessage(String.valueOf(BasicCommands.ADD_COMPUTER));
        if(readLineFromServer()!=null){
            //view.update(readLineFromServer());
        }else throw new ServerUnavailableException("Could not add computer");
    }

    public void removeComputer() throws ServerUnavailableException{
        sendMessage(String.valueOf(BasicCommands.REMOVE_COMPUTER));
        if(readLineFromServer()!=null){
            //view.update(readLineFromServer());
        }else throw new ServerUnavailableException("Could not remove computer");
    }

    public void requestGame(int numberOfPlayers) throws ServerUnavailableException {
        sendMessage(BasicCommands.REQUEST_GAME + Protocol.ARGUMENT_SEPARATOR + numberOfPlayers);
        if(readLineFromServer()!=null){
            view.update(readLineFromServer());
        }else throw new ServerUnavailableException("Could not request game");
    }

    public void playCard(String card) throws ServerUnavailableException{
        sendMessage(BasicCommands.PLAY_CARD + Protocol.ARGUMENT_SEPARATOR + card);
        if(readLineFromServer()!=null){
            view.update(readLineFromServer());
        }else throw new ServerUnavailableException("Could not play card");
    }

    public void drawCard() throws ServerUnavailableException{
        sendMessage(String.valueOf(BasicCommands.DRAW_CARD));
        if(readLineFromServer()!=null){
            view.update(readLineFromServer());
        }else throw new ServerUnavailableException("Could not draw card");
    }

    public static void main(String[] args) {
        (new Client()).start();
    }
}