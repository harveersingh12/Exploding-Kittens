package ClientServer;

import Controller.Game;
import Controller.Players.HumanPlayer;
import Controller.Players.Player;

import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable{
    private BufferedReader in;
    private BufferedWriter out;
    private Socket sock;

    /** The connected HotelServer */
    private Server srv;

    /** Name of this ClientHandler */
    private String name;
    /**
     * Constructs a new HotelClientHandler. Opens the In- and OutputStreams.
     *
     * @param sock The client socket
     * @param srv  The connected server
     * @param name The name of this ClientHandler
     */
    public ClientHandler(Socket sock, Server srv, String name) {
        try {
            in = new BufferedReader(
                    new InputStreamReader(sock.getInputStream()));
            out = new BufferedWriter(
                    new OutputStreamWriter(sock.getOutputStream()));
            this.sock = sock;
            this.srv = srv;
            this.name = name;
        } catch (IOException e) {
            shutdown();
        }
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name=name;
    }

    /**
     * Continuously listens to client input and forwards the input to the
     * {@link #handleCommand(String)} method.
     */
    public void run() {
        String msg;
        try {
            //msg = in.readLine();
            while ((msg = in.readLine()) != null) {
                System.out.println("> [" + name + "] Incoming: " + msg);
                handleCommand(msg);
                out.write("\n");
                out.flush();
                //msg = in.readLine();
            }
            shutdown();
        } catch (IOException e) {
            shutdown();
        }
    }

    /**
     * Handles commands received from the client by calling the according
     * methods at the HotelServer. For example, when the message "i Name"
     * is received, the method doIn() of HotelServer should be called
     * and the output must be sent to the client.
     *
     * If the received input is not valid, send an "Unknown Command"
     * message to the server.
     *
     * @param input command from client
     * @throws IOException if an IO errors occur.
     */

    private void handleCommand(String input) throws IOException{
        String command, parm = null, parm2 = null;
        String[] split;
        split=input.split(Protocol.ARGUMENT_SEPARATOR);
        command=split[0];
        if(split.length >= 2)
            parm=split[1];
        switch(command){
            case "CONNECT":
                if(split.length == 2){
                    out.write((srv.getHello(parm,"no flags".split(" "))));
                    if(parm!=null)
                        this.name = parm;
                }
                else if(split.length == 3){
                    out.write(srv.getHello(parm,split[2].split(",")));
                    if(parm!=null)
                        this.name = parm;
                }
                break;
            case "ADD_COMPUTER":
                out.write(srv.addComputer());
                break;
            case "REMOVE_COMPUTER":
                out.write(srv.removeComputer());
                break;
            case "REQUEST_GAME":
                //out.write("\n Starting game...");
                srv.requestGame(Integer.parseInt(parm));
                break;
            case "PLAY_CARD":
                out.write(srv.playCard(new HumanPlayer(parm)));
                break;
            case "DRAW_CARD":
//                out.write(srv.drawCard(new HumanPlayer(parm),game.getDeck()));
            case "RESPOND_SERVER":

                break;
//            case "SEND":
//                out.write(srv.sendMessage(parm));
//                break;
            default:
                out.write("Unknown command");
        }

    }

    public String getResponse(String command){
        String message =null;
        try {
            while((message = in.readLine()) == null){
                message =  in.readLine();
            }
        }catch (IOException e){
            e.printStackTrace();
        }

        return message;
    }

    public void send(String message){
        try {
            out.write(message);
            out.newLine();
            out.flush();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    private void shutdown() {
        System.out.println("> [" + name + "] Shutting down.");
        try {
            in.close();
            out.close();
            sock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        srv.removeClient(this);
    }
}