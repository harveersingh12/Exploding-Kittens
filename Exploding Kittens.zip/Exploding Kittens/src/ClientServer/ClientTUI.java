package ClientServer;

import ClientServer.Client;
import Utils.Exceptions.ExitProgram;
import Utils.Exceptions.ServerUnavailableException;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Scanner;

public class ClientTUI {

    Client client;

    public ClientTUI(Client client){
        this.client=client;
    }

    public void update(String message){
        System.out.println(message);
    }

    public void start(){
        try {
            while(true){
                //update("Please enter a command: ");
                String userInput=keyboardStringInput();
                handleUserInput(userInput);
            }
        }
        catch (Exception e){
            update("Exiting the program...");
        }
    }

    public void handleUserInput(String input) throws ExitProgram, ServerUnavailableException {
        String command, parm, parm2;
        String[] split;
        split=input.split(Protocol.ARGUMENT_SEPARATOR);
        command=split[0];
        parm=split[1];
        if(split.length > 2) {
            parm2=split[2];
        }
        switch(command){
            case "ADD_COMPUTER":
                client.addComputer();
                break;
            case "REMOVE_COMPUTER":
                client.removeComputer();
                break;
            case "REQUEST_GAME":
                client.requestGame(Integer.parseInt(parm));
                break;
            case "PLAY_CARD":
                client.playCard(parm);
                break;
            case "DRAW_CARD":
                client.drawCard();
                break;
            case "SEND":
                client.sendMessage(parm);
                break;
        }
    }
    public String keyboardStringInput(){
        Scanner stringScanner = new Scanner(System.in);
        return stringScanner.nextLine();
    }

    public int keyboardIntInput(){
        Scanner intScanner = new Scanner(System.in);
        int number = intScanner.nextInt();
        intScanner.nextLine();
        return number;
    }

    public InetAddress getIp(){
        while(true){
            try {
                update("Enter a server IP address: ");
                String userInput=keyboardStringInput();
                return InetAddress.getByName(userInput);
            } catch (Exception e) {
                update("Invalid IP address. Please enter a valid IP address.");
            }
        }
    }

    public boolean checkFlags(String[] flagInput){
        for (String s : flagInput) {
            int value=-1;
            try {
                value=Integer.parseInt(s);
            } catch (Exception e) {
                return false;
            }
            if(value<0||value>6) return false;
        }
        return true;
    }
}