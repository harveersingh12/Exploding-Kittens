package ClientServer;

import ClientServer.Protocol;
import Controller.Game;
import Controller.Players.ComputerPlayer;
import Controller.Players.HumanPlayer;
import Controller.Players.Player;
import Model.Card;
import Model.CardType;
import Model.Deck;
import Utils.Exceptions.*;
import View.UserInterface;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server implements Runnable {
    /**
     * List of all server commands in the game that will be present regardless of whether
     * bonus features are implemented. These commands are used in starting a game, playing
     * it and displaying information to the client.
     */


    public enum BasicCommands implements Protocol.Command {
        HELLO,PLAYER_LIST,QUEUE,NEW_GAME,CURRENT,SHOW_HAND,GAME_OVER,ERROR,BROADCAST_MOVE,PLAYER_OUT
    }

    /**
     * List of commands that are required upon implementing the chat feature and/or
     * the multi-game feature. LOBBY_LIST is a display of all open games and their player
     * limit. MESSAGE relays a message from one player to all others.
     * This list can be extended if needed.
     */
    public enum AdvancedCommand implements Protocol.Command {
        LOBBY_LIST,MESSAGE
    }

    /**
     * The ServerSocket of this HotelServer
     */
    private ServerSocket ssock;

    /**
     * List of HotelClientHandlers, one for each connected client
     */
    public static List<ClientHandler> clients;
    //public static ArrayList<ClientTUI> ClientTUIs = new ArrayList<>();

    /**
     * Next client number, increasing for every new connection
     */
    private int next_client_no;

    /**
     * The view of this HotelServer
     */
    private ServerTUI view;
    private ArrayList<Player> players;
    private ArrayList<String> playerNames;
    //private HotelServerTUI view;

    /**
     * Constructs a new HotelServer. Initializes the clients list,
     * the view and the next_client_no.
     */
    public Server(){
        //ClientTUIs = new ArrayList<>();
        clients=new ArrayList<>();
        view=new ServerTUI();
        next_client_no=1;
        players=new ArrayList<>();
        playerNames=new ArrayList<>();
    }

    /**
     * Opens a new socket by calling {@link #setup()} and starts a new
     * HotelClientHandler for every connecting client.
     * <p>
     * If {@link #setup()} throws a ExitProgram exception, stop the program.
     * In case of any other errors, ask the user whether the setup should be
     * run again to open a new socket.
     */
    public void run(){
        boolean openNewSocket=true;
        while(openNewSocket){
            try {
                // Sets up the hotel application
                setup();

                while(true){
                    Socket sock=ssock.accept();
                    String name="Client "+String.format("%02d",next_client_no++);
                    view.update("New client ["+name+"] connected!");
                    ClientHandler handler=new ClientHandler(sock,this,name);
                    System.out.println(sock);
                    new Thread(handler).start();
                    clients.add(handler);
                }

            } catch (ExitProgram e1) {
                // If setup() throws an ExitProgram exception,
                // stop the program.
                openNewSocket=false;
            } catch (IOException e) {
                System.out.println("A server IO error occurred: "+e.getMessage());

                if(!view.getBoolean("Do you want to open a new socket?")){
                    openNewSocket=false;
                }
            }
        }
        view.update("See you later!");
    }

    /**
     * Sets up a new Hotel using {@link ()} and opens a new
     * ServerSocket at localhost on a user-defined port.
     * <p>
     * The user is asked to input a port, after which a socket is attempted
     * to be opened. If the attempt succeeds, the method ends, If the
     * attempt fails, the user decides to try again, after which an
     * ExitProgram exception is thrown or a new port is entered.
     *
     * @throws ExitProgram if a connection can not be created on the given
     *                     port and the user decides to exit the program.
     * @ensures a serverSocket is opened.
     */
    public void setup() throws ExitProgram{

        ssock=null;
        while(ssock==null){
            view.update("Please enter the server port.");
            int port=view.keyboardIntInput();

            // try to open a new ServerSocket
            try {
                view.update("Attempting to open a socket at 127.0.0.1 "+"on port "+port+"...");
                ssock=new ServerSocket(port,0,InetAddress.getByName("127.0.0.1"));
                view.update("Server started at port "+port);
            } catch (IOException e) {
                view.update("ERROR: could not create a socket on "+"127.0.0.1"+" and port "+port+".");

                if(!view.getBoolean("Do you want to try again?")){
                    throw new ExitProgram("User indicated to exit the "+"program.");
                }
            }
        }
    }

    /**
     * Removes a clientHandler from the client list.
     *
     * @requires client != null
     */
    public void removeClient(ClientHandler client){
        this.clients.remove(client);
    }

    public String getHello(String name,String[] flags){
        playerNames.add(name);
        players.add(new HumanPlayer(name));
        //flag logic
        return BasicCommands.HELLO+Protocol.ARGUMENT_SEPARATOR+name+"~FLAGS";
    }

    public synchronized String addHumanPlayer(String name){
        if(!playerNames.contains(name)){
            if(players.size()<5){
                players.add(new HumanPlayer(name));
                playerNames.add(name);
                return BasicCommands.PLAYER_LIST+Protocol.ARGUMENT_SEPARATOR+playerNames;
            } else return BasicCommands.ERROR+Protocol.ARGUMENT_SEPARATOR+Protocol.Error.E03;
        } else return BasicCommands.ERROR+Protocol.ARGUMENT_SEPARATOR+Protocol.Error.E02;
    }

    public synchronized String addComputer(){
        players.add(new ComputerPlayer("Computer_Player"));
        playerNames.add("Computer_Player");
        return BasicCommands.PLAYER_LIST+Protocol.ARGUMENT_SEPARATOR+playerNames+" "+BasicCommands.QUEUE+Protocol.ARGUMENT_SEPARATOR+players.size();
    }

    public synchronized String removeComputer(){
        for (Player player : players) {
            if(player instanceof ComputerPlayer){
                players.remove(player);
                playerNames.remove(player.getName());
                return "\n"+BasicCommands.PLAYER_LIST+Protocol.ARGUMENT_SEPARATOR+playerNames+" "+players+BasicCommands.QUEUE+Protocol.ARGUMENT_SEPARATOR+players.size();
            }
        }
        return "\n"+BasicCommands.ERROR+Protocol.ARGUMENT_SEPARATOR+Protocol.Error.E06;
    }


    public synchronized void requestGame(int numberOfPlayers){
        for (ClientHandler client : clients) {
            boolean exists=false;
            for (Player player : players)
                if(player.getName().equals(player.getName())) exists=true;

            if(!exists) players.add(new HumanPlayer(client.getName()));
        }
        playGame();
    }

    private Deck deck;
    private int current;
    private boolean dontDraw, endTurn, nopePlayed, network;
    private int remainingTurns;
    Player currentPlayer;

    public void playGame(){
        current=0;
        boolean gameOver=false;
        Game.numberOfPlayers=players.size();
        deck=new Deck();
        //System.out.println(deck);
        //initializeHands(deck);

        if(!gameOver){
            currentPlayer=players.get(current);
            System.out.println(currentPlayer);
            askPlayer(currentPlayer,currentPlayer.getName()+"'s turn");
            askPlayer(currentPlayer,"Chance of drawing an exploding kitten: "+deck.chanceOfEk()+"%");
            askPlayer(currentPlayer,String.valueOf(deck.drawPile.size()));
            //playTurn(currentPlayer);
            //updateCurrent();
        }
    }



    public void askPlayer(Player player, String message){
        synchronized (Server.clients) {
            for (ClientHandler client : Server.clients) {
                if(client.getName().equals(player.getName())){
                    client.send(message);
                }
            }
        }
    }

    public synchronized void receiveInput(Player player, String message, String command){
        for (ClientHandler client : clients) {
            if(client.getName().equals(player.getName()))
                client.getResponse(command);
        }
    }



    public synchronized String drawCard(Player player, Deck deck) {
        player.drawCard(deck);
        return BasicCommands.CURRENT + Protocol.ARGUMENT_SEPARATOR + BasicCommands.SHOW_HAND;
    }

//    public synchronized String sendMessage(String msg){
//        return AdvancedCommand.MESSAGE + Protocol.ARGUMENT_SEPARATOR + view.update(msg);
//    }

    public synchronized String playCard(Player player) {
        player.playCard();
        return BasicCommands.CURRENT + Protocol.ARGUMENT_SEPARATOR + BasicCommands.BROADCAST_MOVE;
    }


    // ------------------ Main --------------------------
    /** Start a new HotelServer */
    public static void main(String[] args) {
        Server server = new Server();
        System.out.println("Welcome to MY PASSING PROJECT the ! Starting...");
        new Thread(server).start();
    }
}