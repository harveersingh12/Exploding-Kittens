package ClientServer;

import java.net.InetAddress;
import java.util.Scanner;

public class ServerTUI {
    public void update(String message){
        System.out.println(message);
    }

    public String keyboardStringInput(){
        Scanner stringScanner = new Scanner(System.in);
        return stringScanner.nextLine();
    }

    public int keyboardIntInput(){
        Scanner intScanner = new Scanner(System.in);
        int number = intScanner.nextInt();
        intScanner.nextLine();
        return number;
    }

    public InetAddress getIp(){
        while(true){
            try {
                update("Enter a server IP address: ");
                String userInput=keyboardStringInput();
                return InetAddress.getByName(userInput);
            } catch (Exception e) {
                update("Invalid IP address. Please enter a valid IP address.");
            }
        }
    }

    public boolean getBoolean(String message){
        while(true){
            update(message);
            String userInput=keyboardStringInput();
            if(userInput.equals("yes")){
                return true;
            } else if(userInput.equals("no")){
                return false;
            } else {
                update("Please enter a value that is yes or no");
            }
        }
    }
}
