package Controller;

import Model.Deck;
import Model.Card;
import Model.CardType;
import Utils.ExplodingKittens;
import Controller.Players.HumanPlayer;
import Controller.Players.Player;
import View.UserInterface;

import java.util.*;

public class Game {
    //this class contains the methods that are needed for the game to work


    public static int numberOfPlayers;
    private Deck deck;
    private UserInterface view;
    private int current;
    private ArrayList<Player> players;
    private ArrayList<String> playerNames;
    private ArrayList<String> markedList;
    private boolean dontDraw, endTurn, nopePlayed;
    private int remainingTurns;


    public Game(ArrayList<Player> players, UserInterface view) {
        this.view = view;
        this.players = players;
        playerNames = new ArrayList<>();
        numberOfPlayers = players.size();
        markedList = new ArrayList<>();
        current = 0;
        remainingTurns = 0;
        deck = new Deck();
        initializeHands(deck);
        for(Player player : players){
            playerNames.add(player.getName());
        }
    }

    public void initializeHands(Deck deck){
        players.replaceAll(player -> new HumanPlayer(player.getName(), deck));
    }

    public Deck getDeck(){
        return deck;
    }

    public ArrayList<Player> getPlayers(){
        return players;
    }

    public Game(){}
    public void start(){
        boolean continueGame = true;
        while (continueGame) {
            reset();
            play();
            view.update("\n> Play another time? (y/n)?");
            String playAgain =view.keyboardStringInput();
            continueGame = playAgain.equals("y");
        }
    }

    public void reset(){
        current = 0;
        deck.resetDeck();
        deck.shuffle();
        players.clear();
        playerNames.clear();

        for (int i = 0; i < numberOfPlayers; i++) {
            players.add(new HumanPlayer("Player " + (i + 1), deck));
            playerNames.add(players.get(i).getName());
        }
    }
    private void updateCurrent(){
        current=(current+1) % numberOfPlayers;
    }

    private void setCurrent(int index){
        current = index;
    }

    public void play() {
        while (!gameOver()) {
            Player currentPlayer = players.get(current);

            view.update( currentPlayer.getName() + "'s turn");
            view.update("Chance of drawing an exploding kitten: " + deck.chanceOfEk()+"%");
            view.update(String.valueOf(deck.drawPile.size()));

            playTurn(currentPlayer);
            updateCurrent();
        }
        view.update(players.get(0).getName() + ", you won!");
    }

    public void playTurn(Player player){
        nopePlayed = false;
        dontDraw = false;
        if(ExplodingKittens.flags.contains(ExplodingKittens.EXTENSION_FLAG)) {
            view.update("Marked cards: " + markedList);
        }
        do{
            ArrayList<Card> playedCardList = player.playCard();
            if(playedCardList!= null) {
                markedCards(playedCardList.get(0));

                if(playedCardList.size() == 1){
                    singleCard(player, playedCardList);
                    if(!dontDraw){
                        doDraw(player);
                        break;
                    }

                }else if(playedCardList.size() == 2) {
                //MAY EXIST SOME BUGS WITH THE FLAG IMPLEMENTATION
                    if(ExplodingKittens.flags.contains(ExplodingKittens.COMBO_FLAG)){
                        doubleCombo(player, playedCardList);
                        if(!dontDraw){
                            doDraw(player);
                            break;
                        }
                    } else {
                        view.update("Combos are not enabled in this game.");
                    }

                } else if(playedCardList.size() == 3){
                    if(ExplodingKittens.flags.contains(ExplodingKittens.COMBO_FLAG)){
                        tripleCombo(player,playedCardList);
                        if(!dontDraw){
                            doDraw(player);
                            break;
                        }
                    } else {
                        view.update("Combos are not enabled in this game.");
                    }
                }else if(playedCardList.size() == 5) {
                    if (ExplodingKittens.flags.contains(ExplodingKittens.PARTY_FLAG)) {
                        quintupleCombo(player, playedCardList);
                        if (!dontDraw) {
                            doDraw(player);
                            break;
                        }
                    } else view.update("Team-play is not enabled in this game.");
                }
            } else{
                Card drawnCard;
                if(player.getHand().isCursed()){
                    do {
                        doDraw(player);
                        drawnCard = player.getHand().getCards().get(player.getHand().getCards().size() - 1);
                        if(drawnCard.getType() == CardType.EXPLODING_KITTEN) {
                            break;
                        }
                    } while (drawnCard.getType() == CardType.FERAL_CAT || drawnCard.getType() == CardType.RAINBOW_RALPHING || drawnCard.getType() == CardType.TACO_CAT ||
                            drawnCard.getType() == CardType.BEARD_CAT || drawnCard.getType() == CardType.CATTERMELON);
                    if(drawnCard.getType() == CardType.EXPLODING_KITTEN){
                        defuseEK(drawnCard, player);
                    }
                    player.getHand().setCurse();
                }else {
                    doDraw(player);
                    break;
                }
            }
        }while(nopePlayed);
    }

    private void singleCard(Player player, ArrayList<Card> playedCardList){
        Card playedCard=playedCardList.get(0);
        endTurn=false;

        while(playedCard!=null){
            if(playedCard.getType()!=CardType.DEFUSE && playedCard.getType()!=CardType.NOPE && !player.isCatCard(playedCard)){
                if(anyPlayerWantsToNope()){
                    nopePlayed = true;
                    dontDraw = true;
                    break;
                }
            }
            switch(playedCard.getType()){
                case NOPE:
                    view.update("You cannot play a NOPE right now");
                    player.getHand().addCard(playedCard);
                    break;
                case DEFUSE: // can only be played if exploding kitten was drawn, otherwise an error message is displayed. If valid, the player
                    // puts the exploding kitten back in the pile with the position of the card being at their discretion.
                    view.update("You cannot play a defuse card at the moment");
                    player.getHand().getCards().add(playedCard);
                    break;
                case ATTACK: // next player is made to play two turns, current player does not draw
                    //compound for > 2 players (max 4 cards)
                    attackCase(player);
                    break;
                case SKIP:
                    // current player does not do anything, turn is simply moved on to the next player
                    break;
                case SHUFFLE: // deck is shuffled
                    deck.shuffle();
                    view.update("The draw pile has been shuffled");
                    break;
                case FAVOR: // current player chooses another player to steal a card from, that player chooses a card to give away
                    favorCase(player);
                    break;
                case SEE_THE_FUTURE:
                    for (int i=0; i<3; i++) {
                        view.update(deck.drawPile.get(i).getName());
                    }
                    break;
                case DRAW_FROM_THE_BOTTOM:
                    dontDraw = true;
                    endTurn = true;
                    if(deck.getDrawPile() != null){
                        Card drawnCard=deck.getDrawPile().get(deck.getDrawPile().size()-1);
                        if(drawnCard!=null) {
                            player.getHand().addCard(drawnCard);
                            deck.addDiscardRemoveDrawPile(drawnCard);
                            view.update("Player " + player.getName() + ", you drew the card " + drawnCard.getName() + "." + "\nHand updated:\n" + player.getHand());
                            checkEK(drawnCard, player);
                        }
                    }
                    break;
                case ALTER_THE_FUTURE:
                   alterTheFuture3Case();
                    break;
                case FERAL_CAT:
                    view.update("This card is powerless on its own.");
                    player.getHand().addCard(playedCard);
                    break;
                default:
                    if(ExplodingKittens.flags.contains(ExplodingKittens.EXTENSION_FLAG)){
                        switch(playedCard.getType()){
                            case STREAKING_KITTEN:
                                view.update("You cannot play this card, it only gives you the ability to hold an exploding kitten");
                                player.getHand().addCard(playedCard);
                                break;
                            case EXPLODING_KITTEN:
                                Card isDefuse = player.playSingleCard();
                                while(isDefuse != null){
                                    if(isDefuse.getType()==CardType.DEFUSE){
                                        view.update("You defused an exploding kitten");
                                        view.update("Please select a location in the draw pile to re-insert the exploding kitten");
                                        view.update("The size of the draw pile is: " + deck.drawPile.size());
                                        int ekIndex =view.keyboardIntInput()-1;
                                        while(ekIndex < 0 || ekIndex > deck.drawPile.size() - 1){
                                            view.update("Please insert a valid location. It should be between " + 1  + " and " + deck.drawPile.size());
                                            ekIndex =view.keyboardIntInput();
                                        }
                                        deck.drawPile.add(ekIndex, playedCard);
                                        player.getHand().getCards().remove(playedCard);
                                        return;
                                    } else {
                                        view.update("You can only play a defuse card here");
                                        isDefuse=player.playSingleCard();
                                    }
                                }
                                players.remove(player);
                                break;
                                // could make this more efficient by calling defuseEK but the problem is that the streaking kitten will still be in hand; so it won't go to the defuse logic
                            case SUPER_SKIP:
                                dontDraw = true;
                                remainingTurns = 0;
                                moveToNextPlayer();
                                endTurn = true;
                                break;
                            case SEE_THE_FUTURE_5X:
                                for (int i=0; i<5; i++) {
                                    view.update(deck.drawPile.get(i).getName());
                                }
                                break;
                            case ALTER_THE_FUTURE_5X:
                                alterTheFuture5Case();
                                break;
                            case SWAP_TOP_AND_BOTTOM:
                                deck.drawPile.set(0,deck.drawPile.get(deck.drawPile.size()-1));
                                deck.drawPile.set(deck.drawPile.size()-1, deck.drawPile.get(0));
                                view.update("Top card and bottom card have been swapped");
                                break;
                            case GARBAGE_COLLECTION:
                                for(Player p: players){
                                    boolean validCard = false;
                                        while(!validCard){
                                            Card cardToInsert;
                                            if(!p.getHand().getCards().isEmpty()){
                                                if(!p.getHand().isCursed()){
                                                    view.update(p.getName() + ", please select a card to insert randomly into the draw pile \n" + p.getHand());
                                                    String input = view.keyboardStringInput();
                                                    cardToInsert = p.findCardByName(input);
                                                }else {
                                                    view.update(p.getName() + ", please select a card index to insert randomly into the draw pile \n" + p.getHand());
                                                    int input = view.keyboardIntInput() - 1;
                                                    while(input < 0 || input >= p.getHand().getCards().size()){
                                                        input = view.keyboardIntInput() -1;
                                                    }
                                                    cardToInsert = p.getHand().getCards().get(input);
                                                }

                                                    if(cardToInsert != null) {
                                                        p.getHand().getCards().remove(cardToInsert);
                                                        Random random = new Random();

                                                        int randomIndex = random.nextInt(deck.drawPile.size()-1);
                                                        deck.drawPile.add(randomIndex, cardToInsert);
                                                        validCard = true;
                                                    }
                                                }
                                            }
                                        }
                                deck.shuffle();
                                view.update("Garbage has been collected and the deck has been shuffled");
                                break;
                            case CATOMIC_BOMB:
                                ArrayList<Card> listOfEk = new ArrayList<>();
                                view.update("Exploding kittens in the deck:");
                                for(Card card: new ArrayList<>(deck.drawPile)){
                                    if(card.getType() == CardType.EXPLODING_KITTEN){
                                        view.update(card.getName());
                                        deck.drawPile.remove(card);
                                        listOfEk.add(card);
                                    }
                                }
                                deck.shuffle();
                                for(Card ek : listOfEk){
                                    deck.drawPile.add(0,ek);
                                }
                                endTurn = true;
                                dontDraw = true;
                                break;
                            case MARK:
                                view.update("Choose a player to mark:");
                                Player markedPlayer = askForName(player.getName());
                                int markedCardIndex;

                                if(markedPlayer!=null){
                                 view.update("Pick a random number between 1 and " + markedPlayer.getHand().getCards().size());
                                 while(true){
                                     markedCardIndex = view.keyboardIntInput()-1;
                                    if(markedCardIndex >= 0 && markedCardIndex < markedPlayer.getHand().getCards().size()){
                                        break;
                                    }
                                     else {
                                         view.update("Pick a valid number");
                                    }
                                 }

                                 Card markedCard = markedPlayer.getHand().getCards().get(markedCardIndex);
                                 markedList.add(markedPlayer.getName() + ": " + markedCard.getName());
                                }
                                break;
                            case CURSE_OF_THE_CAT_BUTT:
                                view.update("Choose a player to curse: ");
                                Player unluckyPlayer = askForName(player.getName());
                                if(unluckyPlayer != null){
                                    unluckyPlayer.getHand().setCurse();
                                }
                                break;
                        }
                    }
                    if(playedCard.getType() == CardType.TACO_CAT || playedCard.getType() == CardType.RAINBOW_RALPHING
                            || playedCard.getType() == CardType.BEARD_CAT || playedCard.getType() == CardType.CATTERMELON
                            || playedCard.getType() == CardType.HAIRY_POTATO){
                        view.update("This card is powerless on its own.");
                        if(!player.getHand().isCursed()){
                            player.getHand().addCard(playedCard);
                        }
                    }
                    else if(playedCardList.size()==0)
                        view.update("Please play a card in your hand");
            }

            if(playedCard.getType()==CardType.SKIP){
                dontDraw=true;
                break;
            }

            if(!endTurn){
                playedCardList=player.playCard();
                if(playedCardList != null &&  playedCardList.size()==1)
                    playedCard=playedCardList.get(0);
                else playedCard= null;
            } else {
                playedCard=null;
            }
        }
    }

    private void moveToNextPlayer() {
        setCurrent((current + 1) % players.size());
    }

    private void markedCards(Card card){
        markedList.removeIf(s -> s.contains(card.getName()));
    }

    private void doubleCombo(Player player, ArrayList<Card> playedCardList){
        while (playedCardList != null) {

            String currentPlayerName = player.getName();

            view.update("You played a two card combo, select a player to take a random card from: ");
            if (anyPlayerWantsToNope()) {
                nopePlayed = true;
                dontDraw = true;
                break;
            }
            Player stealPlayer = askForName(currentPlayerName);
            int stealCardIndex;
            if(stealPlayer!=null) {
                view.update("Choose the index of a card to steal from player " + stealPlayer.getName()
                        + ". Size of hand is: " + stealPlayer.getHand().getCards().size());

                stealCardIndex = view.keyboardIntInput() - 1;

                while (stealCardIndex < 0 || stealCardIndex > stealPlayer.getHand().getCards().size() - 1) {
                    view.update("Please insert a valid index. You can choose a number between 1 and " + stealPlayer.getHand().getCards().size());
                    stealCardIndex = view.keyboardIntInput() - 1;
                }

                Card stealCard = null;

                for (int i = 0; i < stealPlayer.getHand().getCards().size(); i++)
                    if (i == stealCardIndex) {
                        stealCard = stealPlayer.getHand().getCards().get(i);
                        markedCards(stealCard);
                        break;
                    }

                stealPlayer.getHand().removeCard(stealCard);
                player.getHand().addCard(stealCard);
                view.update("You stole from " + stealPlayer.getName() + " the card " + stealCard.getName());
            }
            playedCardList = player.playCard();
            if(playedCardList != null){
                if(playedCardList.size()==1){
                    singleCard(player,playedCardList);
                    return;
                } else if(playedCardList.size()==3){
                    tripleCombo(player,playedCardList);
                    return;
                }else if(ExplodingKittens.flags.contains(ExplodingKittens.PARTY_FLAG)){
                    if(playedCardList.size()==5){
                        quintupleCombo(player, playedCardList);
                    }
                }
            }
        }
    }

    public void tripleCombo(Player player, ArrayList<Card> playedCardList){
        while(playedCardList != null){

            view.update("You played a three card combo, select a player to take a random card from:");
            if(playedCardList.get(0).getType() != CardType.DEFUSE){
                if (anyPlayerWantsToNope()) {
                    nopePlayed = true;
                    dontDraw = true;
                    break;
                }
            }

            Player steal3Player = askForName(player.getName());

            view.update("Enter the index of a card type that you would like to steal from."+steal3Player.getName());

            for (int i=0; i<CardType.values().length; i++) {
                if(CardType.values()[i]!=CardType.EXPLODING_KITTEN) {
                    view.update((i+1)+". "+CardType.values()[i]);
                }
            }
            int typeIndex=view.keyboardIntInput()-1;

            while(typeIndex<0||typeIndex>CardType.values().length-1||CardType.values()[typeIndex]==CardType.EXPLODING_KITTEN){
                view.update(typeIndex+" is not a valid card type. Enter again!");
                typeIndex=view.keyboardIntInput()-1;
            }

            if(!steal3Player.getHand().containsCardType(CardType.values()[typeIndex])){
                view.update("You get nothing! HAHAHAHA!");
            } else {
                Card steal3Card=null;
                for (Card card : steal3Player.getHand().getCards())
                    if(card.getType()==CardType.values()[typeIndex]){
                        steal3Card=card;
                        markedCards(card);
                        break;
                    }
                player.getHand().addCard(steal3Card);
                steal3Player.getHand().removeCard(steal3Card);
                view.update("You stole a "+CardType.values()[typeIndex].toString()+" from "+steal3Player.getName());
            }
            playedCardList = player.playCard();

            if(playedCardList != null){
                if(playedCardList.size()==1){
                    singleCard(player,playedCardList);
                    return;
                } else if(playedCardList.size()==2){
                    doubleCombo(player,playedCardList);
                    return;
                }else if(ExplodingKittens.flags.contains(ExplodingKittens.PARTY_FLAG)){
                    if(playedCardList.size()==5){
                        quintupleCombo(player, playedCardList);
                    }
                }
            }
        }
    }

    private void quintupleCombo(Player player, ArrayList<Card> playedCardList){
        while(playedCardList!=null){
            Card chosenCard = null;
            view.update("You played a five card combo, select any card from the discard pile");
            for(Card card: deck.discardPile){
                view.update(card.getName());
            }
            while(chosenCard == null){
            String input = view.keyboardStringInput();
            for(Card card: deck.discardPile){
                if(card.getName().equals(input)){
                    chosenCard = card;
                    break;
                    }
                }if(chosenCard == null){
                view.update("The chosen card must be in the discard pile");
                }
            }
            for (Card card: playedCardList) {
                player.getHand().getCards().remove(card);
                markedCards(card);
            }
            player.getHand().getCards().add(chosenCard);
            deck.discardPile.remove(chosenCard);

            playedCardList = player.playCard();
            if(playedCardList != null){
                if(playedCardList.size()==1){
                    singleCard(player,playedCardList);
                    return;
                } else if(playedCardList.size()==2){
                    doubleCombo(player,playedCardList);
                    return;
                }else if(playedCardList.size()==3){
                        tripleCombo(player, playedCardList);
                    }
                }
            }
        }


    private Player askForName(String currentPlayerName){
        for (String name : playerNames) {
            if (!name.equals(currentPlayerName)) {
                view.update(name);
            }
        }
        String playerName = view.keyboardStringInput();
        while(!playerNames.contains(playerName) || playerName.equals(currentPlayerName)){
            view.update("Please select a valid player name, you can choose from the following options:");
            for (String name : playerNames) {
                if (!name.equals(currentPlayerName)) {
                    view.update(name);
                }
            }
            playerName = view.keyboardStringInput();
        }
        for(Player player: players){
            if(player.getName().equals(playerName)){
                return player;
            }
        }
        return null;
    }

    public boolean anyPlayerWantsToNope() {
        boolean actionCanceled = false;
        Player lastNopePlayer = null;

        while (true) {
            boolean nopePlayed = false;

            for (Player player : players) {
                if (player == lastNopePlayer) {
                    continue;
                }

                if (player != players.get(current) && player.hasNopeCard()) {
                    view.update(player.getName() + ", do you want to play a Nope card to cancel the action? (yes/no)");
                    String nopeChoice = view.keyboardStringInput().toLowerCase();

                    if (nopeChoice.equals("yes")) {
                        player.playNopeCard();
                        view.update("Action canceled by playing a Nope card.");
                        actionCanceled = true;
                        nopePlayed = true;
                        lastNopePlayer = player;
                    } else if (nopeChoice.equals("no")) {
                        break;
                    } else {
                        view.update("Invalid input. Please enter 'yes' or 'no'.");
                    }
                }
            }

            if (nopePlayed && players.get(current).hasNopeCard()) {
                view.update(players.get(current).getName() + ", do you want to play a Nope card to cancel the previous Nope? (yes/no)");
                String originalNopeChoice = view.keyboardStringInput().toLowerCase();

                if (originalNopeChoice.equals("yes")) {
                    players.get(current).playNopeCard();
                    view.update("Previous Nope action canceled by playing a Nope card.");
                    actionCanceled = false;
                    lastNopePlayer = players.get(current);
                } else {
                    break;
                }
            } else {
                break;
            }
        }

        return actionCanceled;
    }

    public void doDraw(Player player){
        Card drawnCard=player.drawCard(deck);
        checkEK(drawnCard,player);
    }

    public void alterTheFuture5Case() {
        ArrayList<Card> cardsToAlter = new ArrayList<>();
        String[] split = null;
        boolean validList = false;

        view.update("Rearrange the following cards in whatever order of indices you would like (split each index with a ,): ");

        for (int i = 0; i < 5; i++) {
            cardsToAlter.add(deck.drawPile.get(i));
            view.update((i + 1) + ": " + deck.drawPile.get(i).getName());
            deck.drawPile.remove(0);
        }

        while (!validList) {
            String input = view.keyboardStringInput();
            split = input.split(",");
            HashSet<String> uniqueList = new HashSet<>(Arrays.asList(split));

            if (uniqueList.size() == 5) {
                boolean indicesWithinRange = true;

                for (String index : split) {
                    int alteredIndex = Integer.parseInt(index)-1;
                    if (alteredIndex < 0 || alteredIndex >= cardsToAlter.size()) {
                        indicesWithinRange = false;
                        break;
                    }
                }
                validList = indicesWithinRange;
            }

            if (!validList) {
                view.update("Please provide a list of five unique indices in the given range (1 to 5)");
            }
        }

        ArrayList<Card> alteredCards = new ArrayList<>();
        for (String index : split) {
            int alteredIndex = Integer.parseInt(index) - 1;
            Card alteredCard = cardsToAlter.get(alteredIndex);
            alteredCards.add(alteredCard);
        }

        for (int i = 4; i >= 0; i--) {
            deck.drawPile.add(0, alteredCards.get(i));
        }
    }

    public void alterTheFuture3Case(){
        ArrayList<Card> cardsToAlter = new ArrayList<>();
        String[] split = null;
        boolean validList = false;

        view.update("Rearrange the following cards in whatever order of indices you would like (split each index with a ,): ");

        for (int i = 0; i < 3; i++) {
            cardsToAlter.add(deck.drawPile.get(i));
            view.update((i + 1) + ": " + deck.drawPile.get(i).getName());
            deck.drawPile.remove(0);
        }

        while (!validList) {
            String input = view.keyboardStringInput();
            split = input.split(",");
            HashSet<String> uniqueList = new HashSet<>(Arrays.asList(split));

            if (uniqueList.size() == 3) {
                boolean indicesWithinRange = true;

                for (String index : split) {
                    int alteredIndex = Integer.parseInt(index) - 1;
                    if (alteredIndex < 0 || alteredIndex >= cardsToAlter.size()) {
                        indicesWithinRange = false;
                        break;
                    }
                }

                validList = indicesWithinRange;
            }

            if (!validList) {
                view.update("Please provide a list of three unique indices in the given range (1 to 3)");
            }
        }

        ArrayList<Card> alteredCards = new ArrayList<>();
        for (String index : split) {
            int alteredIndex = Integer.parseInt(index) - 1;
            Card alteredCard = cardsToAlter.get(alteredIndex);
            alteredCards.add(alteredCard);
        }

        for (int i = 2; i >= 0; i--) {
            deck.drawPile.add(0, alteredCards.get(i));
        }
    }
    public void attackCase(Player player) {
        view.update("You played an attack card, select the player you want to attack");

        Player attackedPlayer = askForName(player.getName());

        int attackedPlayerIndex = players.indexOf(attackedPlayer);
        setCurrent(attackedPlayerIndex);
        remainingTurns += 2;

        playTurn(players.get(current));

        remainingTurns--;
        if(remainingTurns != 0) {
            playTurn(players.get(current));

            remainingTurns--;
            for (int i = 0; i < remainingTurns; i++)
                playTurn(players.get(current));
        }
        // Move to the next player (3-turn situation in a 2-player game)
        setCurrent(players.indexOf(player));
        dontDraw = true;
        endTurn = true;
    }


    public void favorCase(Player player){

        String currentPlayerName=player.getName();

        view.update("You played a favor card, select a player to take a card from");

        Player favorPlayer = askForName(currentPlayerName);

        view.update(favorPlayer.getName()+", please select a card to give away. You can choose between the following cards: \n"+favorPlayer.getHand().getNames());
        String givenCardName=view.keyboardStringInput();

        while(!favorPlayer.getHand().getNames().contains(givenCardName)){
            view.update("Please insert a valid name.");
            givenCardName=view.keyboardStringInput();
        }

        Card givenCard=null;
        for (Card card : favorPlayer.getHand().getCards())
            if(card.getName().equals(givenCardName)) {
                givenCard=card;
            }
        if(givenCard!=null){
            markedCards(givenCard);
            favorPlayer.getHand().removeCard(givenCard);
            players.get(current).getHand().addCard(givenCard);
            view.update(givenCardName+" removed from "+favorPlayer.getName()+"'s hand and given to "+currentPlayerName);
                if(ExplodingKittens.flags.contains(ExplodingKittens.EXTENSION_FLAG)){
                    checkEK(givenCard, player);
            }
        }
    }


    private void checkEK(Card card, Player player){
        if(card.getType() == CardType.EXPLODING_KITTEN){
            view.update("You drew an exploding kitten. Play a defuse card if you have one. (type 'no' to get exploded)");
                defuseEK(card, player);
        }
    }

    private void defuseEK(Card card, Player player){
        boolean validInput = false;
        if(ExplodingKittens.flags.contains(ExplodingKittens.EXTENSION_FLAG)){
            for(Card isSK: player.getHand().getCards()){
                if(isSK.getType() == CardType.STREAKING_KITTEN){
                    view.update("You have a streaking kitten. You can hold the exploding kitten");
                    while(!validInput){
                        view.update("Do you still want to defuse (yes/no)?");
                        String defuseChoice = view.keyboardStringInput();
                        switch (defuseChoice){
                            case "yes":
                                view.update("Play a defuse card if you have one. (type 'no' to get exploded)");
                                validInput = true;
                                break;
                            case "no":
                                return;
                            default: view.update("Invalid input, please enter yes or no");
                        }
                    }
                }
            }
        }
        Card isDefuse = player.playSingleCard();
        while(isDefuse != null){
            if(isDefuse.getType()==CardType.DEFUSE){
                view.update("You defused an exploding kitten");
                view.update("Please select a location in the draw pile to re-insert the exploding kitten");
                view.update("The size of the draw pile is: " + deck.drawPile.size());
                int ekIndex =view.keyboardIntInput()-1;
                while(ekIndex < 0 || ekIndex > deck.drawPile.size() - 1){
                    view.update("Please insert a valid location. It should be between " + 1  + " and " + deck.drawPile.size());
                    ekIndex =view.keyboardIntInput();
                    //sometimes the last location doesn't work
                }
                deck.drawPile.add(ekIndex, card);
                player.getHand().getCards().remove(card);
                if(player.getHand().isCursed()){
                    player.getHand().setCurse();
                }
                return;
            } else {
                view.update("You can only play a defuse card here");
                isDefuse=player.playSingleCard();
                if(player.getHand().isCursed()){
                    player.getHand().removeCard(isDefuse);
                }
            }
        }
        players.remove(player);
    }

    public void discard(Card card){
        deck.discardPile.add(card);
    }

    public boolean gameOver(){
        return players.size() == 1;
    }
}