package Controller.Players;

import Model.Card;
import Model.Hand;
import Model.Deck;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class for the computer game player. Will implement a smart
 * strategy to beat human players. It will do so by memorizing all cards
 * played and play the best possible card each turn using probability.
 */
public class ComputerPlayer implements Player{
    private Card card;
    private String name;

    public ComputerPlayer(String name){
        this.name = name;
    }

    @Override
    public Card drawCard(Deck deck) {
        return card;
    }
    @Override
    public ArrayList<Card> playCard() {
        ArrayList<Card> AndreiIsSuperGay = new ArrayList<>();
        return AndreiIsSuperGay;
    }

    @Override
    public ArrayList<Card> playTestCard(Scanner scanner) {
        return null;
    }

    @Override
    public Card playSingleCard(){
        return card;
    }

    @Override
    public boolean hasNopeCard() {
        return false;
    }

    @Override
    public void playNopeCard() {

    }

    @Override
    public Card findCardByName(String cardName) {
        return null;
    }

    @Override
    public boolean isCatCard(Card card) {
        return false;
    }

    @Override
    public String getName(){
        return name;
    }
    @Override
    public Hand getHand() {
        return null;
    }
    //this will represent the class of our computer player
}
