package Controller.Players;

import Model.Card;
import Model.CardType;
import Model.Hand;
import Model.Deck;
import Utils.ExplodingKittens;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Class for human game player, based on basic properties
 * of the Player class.
 * @invariant player has a name and hand
 * @invariant player draws and plays cards from one deck
 */
public class HumanPlayer implements Player {
    private Hand hand;
    private String name;

    /**
     * @param name is the name of the player.
     * Player is constructed with just a name,
     * deck is set through the playCard() method
     */
    public HumanPlayer(String name){
        this.name = name;
    }

    /**
     * @param name, name of the player
     * @param deck, deck from which player draws and gets their hand
     */
    public HumanPlayer(String name, Deck deck){
        this(name);
        this.hand = new Hand(deck);
    }

    /**
     * @requires hand is not null
     * @return hand of the player
     */
    @Override
    public Hand getHand(){
        return hand;
    }
    /**
     * @requires name is not null
     * @return name of the player
     */
    @Override
    public String getName(){
        return name;
    }

    /**
     * @param deck is the game deck from which the draw pile is created.
     * Players draw cards from the draw pile depending on the type of card
     * that they play. The player's hand is updated and displayed after every
     * turn so that they can see what they drew.
     * @requires drawn card, deck and draw pile are not null
     * @return the card drawn by the player
     */
    @Override
    public Card drawCard(Deck deck){
        if(deck.drawPile != null){
        Card drawnCard = deck.drawCard();
            if(drawnCard != null) {
                hand.addCard(drawnCard);
            }
            System.out.println("Player " + name + ", you drew the card " + drawnCard.getName() +"."+
                    "\nHand updated:\n" + hand);
            return drawnCard;
        }return null;
    }
    /**
     * Players have the ability to play a card or pass their turn
     * (by saying 'no') to the next person. To do so, they must select
     * a card to remove from their hand and add to the discard pile.
     * This can be a single card or a double/triple combo. Depending on
     * the card type the corresponding action is executed.
     * @requires player to provide a card from their hand or to respond with 'no'
     * @ensures player is asked for input as long as they don't say 'no'
     * @ensures player plays a valid combination of cards
     * @ensures player can only play card(s) from their hand
     * @return the chosen card(s) from the player's hand stored in a list.
     */
    @Override
    public ArrayList<Card> playCard() {
            System.out.println(name + ", do you want to play a card?\n" + "yes - type the card name\n" + "no - type no");
            System.out.println(hand);
        Scanner keyboard = new Scanner(System.in);
        ArrayList<Card> result;

        while (true) {
            if(hand.isCursed()){
                System.out.println(name +  ", do you want to play a card?\n" + "yes - the card will be chosen randomly\n" + "no - type no");
                System.out.println(hand);
                ArrayList<Card> cursedResult = new ArrayList<>();

                String input = keyboard.nextLine();
                if(input.equals("no")){
                    return null;
                }else{
                        Random random = new Random();
                        int randomIndex = random.nextInt(hand.getCards().size()-1);
                        cursedResult.add(hand.getCards().get(randomIndex));
                        hand.getCards().remove(randomIndex);
                        return cursedResult;
                }
            }
            String input = keyboard.nextLine();

            if (input.equals("no")) {
                return null;
            }

            String[] splitInput = input.split(",");
            if(ExplodingKittens.flags.contains(ExplodingKittens.PARTY_FLAG)){
                if(splitInput.length == 5) {
                    return fiveCardCombo(splitInput);
                }
            }
            result = new ArrayList<>();
            boolean validCombination = true;

            for (String param : splitInput) {
                Card card = findCardByName(param);

                if (card != null) {
                    if (result.isEmpty() || card.getType() == result.get(0).getType() ||
                            (card.getType() == CardType.FERAL_CAT && isCatCard(result.get(0)))){
                        result.add(card);
                    } else {
                        validCombination = false;
                        break;
                    }
                } else {
                    validCombination = false;
                    break;
                }
            }

            if (validCombination && result.size() == splitInput.length) {
                for (Card card : result) {
                    hand.getCards().remove(card);
                }
                break;
            } else {
                System.out.println("Enter a valid combination of cards of the same type. Try again:");
            }
        }

        return result;
    }

    public boolean isCatCard(Card card) {
        return card.getType() == CardType.BEARD_CAT || card.getType() == CardType.CATTERMELON ||
                card.getType() == CardType.TACO_CAT || card.getType() == CardType.RAINBOW_RALPHING ||
                card.getType() == CardType.HAIRY_POTATO;
    }

    private ArrayList<Card> fiveCardCombo(String[] input) {
        ArrayList<Card> result = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        do {
            result.clear();
            CardType currentType = null;
            for (String s : input) {
                Card card = findCardByName(s);
                if (card != null) {
                    if (card.getType() != currentType) {
                        result.add(card);
                    }
                    currentType = card.getType();
                }
            }
            if (result.size() == 5) {
                return result;
            }
            System.out.println("Enter five cards in your hand that are not of the same type");
            String askAgain = scanner.nextLine();
            if (askAgain.equals("no")) {
                return null;
            }
            input = askAgain.split(",");

        } while (true);
    }

    /**
     * @param scanner is meant to allow a predefined input
     * for the played card so that the behavior of playCard()
     * can be verified through unit testing.
     * @return the list of played cards
     */
    @Override
    public ArrayList<Card> playTestCard(Scanner scanner) {
        ArrayList<Card> result = new ArrayList<>();
        String input = scanner.nextLine();
        String[] splitInput = input.split(",");
        boolean validCombination = true;

        if (input.equals("no")) {
            return null;
        }
        for (String param : splitInput) {
            Card card = findCardByName(param);

            if (card != null) {
                if (result.isEmpty() || card.getType() == result.get(0).getType()) {
                    result.add(card);
                } else {
                    validCombination = false;
                    break;
                }
            } else {
                validCombination = false;
                break;
            }
        }

        if (validCombination && result.size() == splitInput.length) {
            for (Card card : result) {
                hand.getCards().remove(card);
            }
        }
        return result;
    }

    /**
     * @param cardName, the String name of the card
     * that needs to be found
     * @requires card name is valid and in the player's hand
     * @return the card of type Card if the card name
     * is found in the player's hand
     */
    @Override
    public Card findCardByName(String cardName) {
        for (Card card : hand.getCards()) {
            if (card.getName().equals(cardName)) {
                return card;
            }
        }
        return null;
    }

    /**
     * Only allows the player to play a single card.
     * @return the played card
     */

    public Card playSingleCard() {
        System.out.println(name + ", do you want to play a card?\n" + "yes - type the card name\n" + "no - type no");
        System.out.println(hand);

        Scanner keyboard = new Scanner(System.in);

        while (true) {
            String input = keyboard.nextLine();

            if (input.equals("no")) {
                return null;
            }

            for (Card card : new ArrayList<>(hand.getCards())) {
                if (card.getName().equals(input)) {
                    hand.getCards().remove(card);
                    return card;
                }
            }
            System.out.println("You do not have that card in your hand. Try again:");
        }
    }

    /**
     * Checks the player's hand for a nope card
     * @return whether a nope card is present
     */

    @Override
    public boolean hasNopeCard() {
        for (Card card : hand.getCards()) {
            if (card.getType() == CardType.NOPE) {
                return true;
            }
        }
        return false;
    }
    /**
     * This method attempts to find a nope card and if
     * successful, removes the nope card from the player's hand
     * @requires found card is not null
     */
    @Override
    public void playNopeCard() {
        Card nope = hand.findCard(CardType.NOPE);
        if (nope != null) {
            hand.removeCard(nope);
        }
    }

    @Override
    public String toString(){
        return getName();
    }
}
