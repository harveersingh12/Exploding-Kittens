package Model;

import Controller.Game;
import Utils.ExplodingKittens;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

/**
 * @invariant all card names are unique and assigned once to a card
 * Creates cards of a given type and name, each of which are added into
 * the drawPile of the Deck class and used in the game by players.
 */

public class Card {
    //this will be the base for every card in our game.
    private String name;
    private CardType type;
    private HashSet<String> usedNames;
    private ArrayList<String> names;
    /**
     * @param type is the card type
     * @param usedNames is the list of card names which have
     * already been set in the current game deck
     * When a card is created it requires a type and the existing
     * list of used card names. Its name is then set and added to
     * the list of used names to ensure its uniqueness.
     */
    public Card(CardType type, HashSet<String> usedNames){
        this.usedNames = usedNames;
        this.type = type;
        names = new ArrayList<>();
        createNames();
        this.name = setName();
    }
    /**
     *
     * type is the input for createName() which will provide a list of card names of this type
     * @return the randomly chosen card name from the list of available cards of the chosen type
     * @ensures the name that gets returned is not of a card that is already in use
     * @ensures the chosen name is added to the list of used card names so that no two cards are the same
     */
    private String setName(){
        int index;
        String localName;
        do {
            index = (int) (Math.random() * names.size());
            name = names.get(index);
        } while (usedNames.contains(name));
            localName=names.get(index);
            usedNames.add(localName);
            return localName;
    }

    public HashSet<String> getUsedNames(){
        return usedNames;
    }

    /**
    *
    **/
    public void createNames(){
        if(ExplodingKittens.flags.contains(ExplodingKittens.PARTY_FLAG)){
            if(Game.numberOfPlayers <= 3)
                listGenerator(CardType.POSITION_PARTY_PAW);
            else if(Game.numberOfPlayers <= 7)
                listGenerator(CardType.POSITION_PARTY_NO_PAW);
            else listGenerator(CardType.POSITION_PARTY_TOTAL);

        }
        else listGenerator(CardType.POSITION_STANDARD);

        if(ExplodingKittens.flags.contains(ExplodingKittens.EXTENSION_FLAG))
            listGenerator(CardType.POSITION_EXTENSION);
    }

    private void listGenerator(int position_amount){
        for (int i = 0; i < type.getAmount().get(position_amount); i++) {
            String name=type.name().toLowerCase()+(i+1);
            names.add(name);
        }
    }

    /**
     *@return the randomly generated name of the card
     */
    public String getName(){
        return name;
    }
    /**
     *@return the type of the card
     */
    public CardType getType(){
        return type;
    }
}
