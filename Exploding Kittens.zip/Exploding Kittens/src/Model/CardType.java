package Model;

import java.util.ArrayList;
import java.util.Collections;

public enum CardType {
   ATTACK(4,4, 7, 0),
   SEE_THE_FUTURE(5, 3, 3, 0),
   SHUFFLE(4,2,4, 0),
   SKIP(4, 4, 6, 0),
   FAVOR(4,2,4, 0),
   NOPE(5,4,6, 0),
   HAIRY_POTATO(4,3,4,0),
   TACO_CAT(4,3,4, 0),
   RAINBOW_RALPHING(4,3,4,0),
   BEARD_CAT(4,3,4, 0),
   CATTERMELON(4,3,4,0),
   ALTER_THE_FUTURE(0,2,4, 0),
   DRAW_FROM_THE_BOTTOM(0,3,4, 0),
   FERAL_CAT(0,2,4, 0),
   SUPER_SKIP(0,0,0,1),
   SEE_THE_FUTURE_5X(0,0, 0,1),
   ALTER_THE_FUTURE_5X(0,0,0,1),
   SWAP_TOP_AND_BOTTOM(0,0,0,3),
   GARBAGE_COLLECTION(0,0,0,1),
   CATOMIC_BOMB(0,0,0,1),
   MARK(0,0,0,3),
   CURSE_OF_THE_CAT_BUTT(0,0,0,2),
   STREAKING_KITTEN(0,0,0,1),
   DEFUSE(6, 3, 7, 0),
   EXPLODING_KITTEN(4, 2, 7, 1);
   private final int STANDARD_AMOUNT;
   private final int PARTY_PACK_AMOUNT_PAW;
   private final int PARTY_PACK_AMOUNT_NO_PAW;
   private final int STREAKING_KITTENS_AMOUNT;

   public static final int POSITION_STANDARD = 0;
   public static final int POSITION_PARTY_PAW = 1;
   public static final int POSITION_PARTY_NO_PAW = 2;
   public static final int POSITION_PARTY_TOTAL = 3;
   public static final int POSITION_EXTENSION = 4;

   public ArrayList<Integer> getAmount(){
      ArrayList<Integer> result = new ArrayList<>();
      Collections.addAll(result, STANDARD_AMOUNT, PARTY_PACK_AMOUNT_PAW, PARTY_PACK_AMOUNT_NO_PAW,
              PARTY_PACK_AMOUNT_NO_PAW + PARTY_PACK_AMOUNT_PAW, STREAKING_KITTENS_AMOUNT);
      return result;
   }

   CardType(int standardAmount, int partyPackAmountPaw, int partyPackAmountNoPaw, int streakingKittensAmount){
      this.STANDARD_AMOUNT = standardAmount;
      this.PARTY_PACK_AMOUNT_PAW = partyPackAmountPaw;
      this.PARTY_PACK_AMOUNT_NO_PAW = partyPackAmountNoPaw;
      this.STREAKING_KITTENS_AMOUNT = streakingKittensAmount;
   }
}

//in this class we have all the card types that exist in the game
