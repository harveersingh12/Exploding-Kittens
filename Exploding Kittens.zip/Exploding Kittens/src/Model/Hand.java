package Model;

import java.util.ArrayList;
import java.util.Random;

public class Hand {
    private ArrayList<Card> cards;
    private ArrayList<String> names;
    private boolean cursed;
    private static final int CARDS_IN_HAND = 7;


    public Hand(Deck deck){
        this.cards = initializeCardsInHand(deck);
        cursed = false;
    }

    private ArrayList<Card> initializeCardsInHand(Deck deck){
        ArrayList<Card> result = new ArrayList<>();
        for(int i = 0; i<CARDS_IN_HAND; i++) {
            int index;
            Card card;
            int attempts = 0;
            do {
                index = generateIndex(deck.drawPile);
                card = deck.getDrawPile().get(index);
                attempts++;
            }while((card.getType() == CardType.EXPLODING_KITTEN || card.getType() == CardType.DEFUSE)
                    && attempts < deck.drawPile.size() - deck.getNUMBER_OF_EK() - deck.getNumberOfDefuse());
            deck.addDiscardRemoveDrawPile(card);
            result.add(card);
        }
        Random random = new Random();
        Card toRemove = null;
        int randomIndex = random.nextInt(result.size() + 1);
        for(Card card : deck.getDrawPile()) {
            if (card.getType() == CardType.DEFUSE){
                result.add(randomIndex,card);
                toRemove = card;
                break;
            }
        }
        deck.addDiscardRemoveDrawPile(toRemove);
        return result;
    }

    private int generateIndex(ArrayList<Card> list){
        if(list.isEmpty()){
            throw new IllegalStateException("List in generate index is empty");
        }
        return (int) (Math.random() * list.size());
    }

    public boolean containsCardType(CardType cardType) {
        for (Card card : cards) {
            if (card.getType() == cardType) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Card> getCards() {
        return cards;
    }


    public ArrayList<String> getNames(){
        setNames();
        return names;
    }

    public void setNames(){
        names = new ArrayList<>();
        for(Card card : cards)
            names.add(card.getName());
    }

    public void addCard(Card card){
        cards.add(card);
    }

    public void clearHand(){
        cards.clear();
    }

    public void removeCard(Card card){
        if(!cards.isEmpty()){
            cards.remove(card);
        }
    }

    public Card findCard(CardType type) {
        for (Card card : cards) {
            if (card.getType() == type) {
                return card;
            }
        }
        return null;
    }

    public boolean isCursed() {
        return cursed;
    }

    public void setCurse(){
        cursed = !cursed;
    }

    @Override
    public String toString(){
        String result = "";
        if (cards.isEmpty()) result += "empty (not good)";
        if(isCursed()){
            result += "You have these cards in your hand: ";
            for (int i=0; i<cards.size(); i++) {
                if(i == cards.size() - 1) result +="BLIND"+".\n";
                else result += "BLIND"+", ";
            }
        }
        else{
            result += "You have these cards in your hand: ";
            for (int i=0; i<cards.size(); i++) {
                if(i == cards.size() - 1) result +=cards.get(i).getName()+".\n";
                else result += cards.get(i).getName()+", ";
            }
        }
        return result;
    }
}