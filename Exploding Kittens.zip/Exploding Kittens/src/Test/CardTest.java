package Test;
import Model.Card;
import Model.CardType;
import Model.Deck;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CardTest {
    Card card;
    Deck deck;

    @BeforeEach
    public void initialization(){
        deck = new Deck();
        card = new Card(CardType.ATTACK, deck.usedNames);
    }

    @Test
    public void validName(){
        assertTrue(card.getName().contains("attack"));
    }


}
