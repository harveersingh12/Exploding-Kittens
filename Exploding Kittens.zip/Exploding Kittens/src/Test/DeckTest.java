package Test;

import Model.CardType;
import Model.Deck;
import Controller.Game;
import Controller.Players.HumanPlayer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DeckTest {
    Deck deck;

    public int calculateNeededSize(){
    int size = 0;
    //add all the cards
    for(CardType type : CardType.values()){
        if(type != CardType.EXPLODING_KITTEN && type != CardType.DEFUSE)
            size += type.getAmount().get(0);
    }
    //add defuse
    if (Game.numberOfPlayers <= 3)
            size += 2;
    else
        size += CardType.DEFUSE.getAmount().get(0) - Game.numberOfPlayers;
    //add ek
    size += deck.getNUMBER_OF_EK();
    return size;
    }


    @BeforeEach
    public void createDeck(){
        deck = new Deck();
    }

    @Test
    public void testInitialization(){
        assertEquals(calculateNeededSize(), deck.drawPile.size());
    }

    @Test
    public void shuffle(){
        Deck shuffledDeck = new Deck();
        shuffledDeck.shuffle();
        assertNotEquals(deck.drawPile, shuffledDeck.drawPile);
    }

    @Test
    public void testDrawCard(){
        Deck origialDeck = new Deck();
        HumanPlayer player = new HumanPlayer("test_player", deck);
        player.drawCard(deck);
        assertNotEquals(deck.drawPile.size(), origialDeck.drawPile.size());
    }

    @Test
    public void testReset(){
        Deck originalDeck = new Deck();
        deck.resetDeck();
        assertNotEquals(deck.drawPile, originalDeck.drawPile);
    }
}
