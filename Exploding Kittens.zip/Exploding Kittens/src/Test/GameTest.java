package Test;


import Controller.Game;
import Controller.Players.HumanPlayer;
import Controller.Players.Player;
import Model.Card;
import Model.CardType;
import View.GameTUI;
import View.UserInterface;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;

// test class for the whole game, checking whether there is a winner, whether the loser is eliminated,
// whether an exploding kitten is put back in the deck after being defused.
//play 2card combo when you have three in hand

public class GameTest {
    Game game;
    UserInterface view;
    Player p1;
    Player p2;

    @BeforeEach
    public void setUp(){
        p1 = new HumanPlayer("player 1");
        p2 = new HumanPlayer("player 2");
        ArrayList<Player> players = new ArrayList<>();
        players.add(p2);
        players.add(p1);
        view = new GameTUI();
        game = new Game(players, view);
        //game.start();
    }


    @Test
    public void testEkInGame(){
        int ekCounter = 0;
        for(Card card: game.getDeck().drawPile){
            if(card.getType()== CardType.EXPLODING_KITTEN){
                ekCounter++;
            }
        }
        Assertions.assertEquals(Game.numberOfPlayers-1,ekCounter);
    }

    @Test
    public void testEkInHand(){
        for(Player player: game.getPlayers()){
            Assertions.assertFalse(player.getHand().containsCardType(CardType.EXPLODING_KITTEN));
        }
    }
    @Test
    public void testNumberOfCards(){
        for(Player player: game.getPlayers()){
            int numberOfCards = 0;
            for (Card card: player.getHand().getCards()){
                numberOfCards++;
            }
            Assertions.assertEquals(8, numberOfCards);
        }
    }

    @Test
    public void testDefuseInHand(){
        for(Player player: game.getPlayers()){
            int numberOfDefuse = 0;
            for (Card card: player.getHand().getCards()){
                if(card.getType() == CardType.DEFUSE){
                    numberOfDefuse++;
                }
            }
            Assertions.assertEquals(1,numberOfDefuse);
        }
    }


}
