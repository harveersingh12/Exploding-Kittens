package Test;
import Model.Card;
import Model.CardType;
import Model.Hand;
import Model.Deck;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class HandTest {
    Deck deck;
    Hand hand;

    @BeforeEach
    public void initialize(){
        deck = new Deck();
        hand = new Hand(deck);
    }

    @Test
    public void numberOfCards(){
        assertEquals(8, hand.getCards().size());
    }

    @Test
    public void containsDefuse(){
        int noDefuses = 0;
        for(Card card : hand.getCards())
            if(card.getType() == CardType.DEFUSE)
                noDefuses++;
        assertEquals(1, noDefuses);
    }

    @Test
    public void testClearHand(){
        hand.clearHand();
        assertTrue(hand.getCards().isEmpty());
    }

    @Test
    public void testRemove(){
        Card card = hand.getCards().get(1);
        hand.removeCard(card);
        assertEquals(7, hand.getCards().size());
    }
}
