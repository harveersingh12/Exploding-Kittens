package Utils.Exceptions;


public class ExitProgram extends Exception {
    public ExitProgram(String message){
        super(message);
    }
}
