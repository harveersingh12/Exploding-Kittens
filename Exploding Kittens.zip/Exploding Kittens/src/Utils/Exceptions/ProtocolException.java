package Utils.Exceptions;

public class ProtocolException extends Exception {

    public ProtocolException(String message) {
        super(message);
    }

}
