package Utils;

import Controller.Game;
import Controller.Players.*;
import Utils.GameBuilder;
import View.GameTUI;
import View.UserInterface;

import java.util.*;

/**
 * Class for playing the game
 * @invariant input for number of players must be an int
 * @invariant player names are unique
 * @invariant number of players in the game is at least 2
 */
public class ExplodingKittens {
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_RESET = "\u001B[0m";
    public static final int PARTY_FLAG = 1;
    public static final int COMBO_FLAG = 4;
    public static final int EXTENSION_FLAG = 5;
    public static ArrayList<Integer> flags = new ArrayList<>();


    public static void main(String[] args) {
        ArrayList<Player> players = new ArrayList<>();

        Set<String> playerNames = new HashSet<>();
        int playerNumber;
        UserInterface view = new GameTUI();
        GameBuilder builder = new GameBuilder();


        view.update("\n"+" _______ ___   ___ .______    __        ______    _______   __  .__   __.   _______     __  ___  __  .___________..___________. _______ .__   __.      _______.\n"
                +"|   ____|\\  \\ /  / |   _  \\  |  |      /  __  \\  |       \\ |  | |  \\ |  |  /  _____|   |  |/  / |  | |           ||           ||   ____||  \\ |  |     /       |\n"
                +"|  |__    \\  V  /  |  |_)  | |  |     |  |  |  | |  .--.  ||  | |   \\|  | |  |  __     |  '  /  |  | `---|  |----``---|  |----`|  |__   |   \\|  |    |   (----`\n"
                +"|   __|    >   <   |   ___/  |  |     |  |  |  | |  |  |  ||  | |  . `  | |  | |_ |    |    <   |  |     |  |         |  |     |   __|  |  . `  |     \\   \\    \n"
                +"|  |____  /  .  \\  |  |      |  `----.|  `--'  | |  '--'  ||  | |  |\\   | |  |__| |    |  .  \\  |  |     |  |         |  |     |  |____ |  |\\   | .----)   |   \n"
                +"|_______|/__/ \\__\\ | _|      |_______| \\______/  |_______/ |__| |__| \\__|  \\______|    |__|\\__\\ |__|     |__|         |__|     |_______||__| \\__| |_______/    \n"+
                "                                                                                                                                                               \n");
        view.update(ANSI_PURPLE + "🎮 Starting game configuration... 🕹" + ANSI_RESET);
        view.update(ANSI_PURPLE + "\nSTEP 1: " + ANSI_RESET + "What flags (optional features) would you like the game to have? Separate multiple flags with (,).");
        view.update("----FLAG LIST----\n"+
                        "0 - Chat\n"+
                        "1 - Teams\n"+
                        "2 - Multi-Games\n"+
                        "3 - Lobby\n"+
                        "4 - Combos\n"+
                        "5 - Extension\n"+
                        "6 - GUI\n"+
                        "no - no flags\n"+
                "-----------------");
        int ok = 1;
        do {
            view.updateSameLine(ANSI_PURPLE + "INPUT HERE: " + ANSI_RESET);
            String[] flagInput = view.keyboardStringInput().split(",");
            if(flagInput[0].equals("no") && flagInput.length==1)
                break;
            for (int i=0; i<flagInput.length; i++) {
                int value = -1;
                try{
                    value=Integer.parseInt(flagInput[i]);
                }catch (NumberFormatException e){
                    view.showError("Please only enter numbers separated by (,) or (no)");
                }
                if(value<0||value>6){
                    view.showError("Invalid flag input. Please try again.");
                    ok = 0;
                } else {
                    flags.add(value);
                    ok = 1;
                }
            }
        }while(ok == 0);

        view.update(ANSI_PURPLE + "\nSelected flags: " + flags + ANSI_RESET);

        view.update(ANSI_PURPLE + "\nSTEP 2: " + ANSI_RESET +"How many players?");
        do {
            try {
                view.updateSameLine(ANSI_PURPLE + "INPUT HERE: " + ANSI_RESET);
                playerNumber = view.keyboardIntInput();

                if (playerNumber < 2) {
                    view.update("The game can only be played with 2 or more players");
                } else{
                    for (int i = 0; i < playerNumber; i++) {
                        view.update( ANSI_PURPLE+"2."+(i+1)+ANSI_RESET+ " Write the name of player " + (i + 1)+".");
                        do {
                            view.updateSameLine(ANSI_PURPLE + "INPUT HERE: " + ANSI_RESET);
                            String name = view.keyboardStringInput();
                            if (playerNames.contains(name)) {
                                view.showError("Multiple players cannot have the same name. Please enter a different name.");
                            } else {
                                playerNames.add(name);
                                Player player = new HumanPlayer(name);
                                players.add(player);
                                break;
                            }
                        } while (true);
                    }

                    view.update(ANSI_PURPLE + "\nSelected players: " + players + ANSI_RESET);

                    builder.withPlayers(players);
                    Game game = new Game(players, view);
                    view.update(ANSI_PURPLE + "\n🕹 Game configured! Have fun! 🎮\n" + ANSI_RESET);
                    game.start();
                    break;
                }
            } catch (InputMismatchException e) {
                view.showError("Please enter a number.");
            }
        } while (true);
    }
}