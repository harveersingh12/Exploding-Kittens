package Utils;

import Controller.Game;
import Controller.Players.Player;
import Model.Deck;

import java.util.List;

public class GameBuilder {
    private List<Player> players;
    private List<Integer> flags;
    private Deck deck;

    public GameBuilder withFlags(List<Integer> flags){
        this.flags = flags;
        return this;
    }

    public GameBuilder withPlayers (List<Player> players){
        this.players = players;
        return this;
    }

    public GameBuilder withDeck (Deck deck){
        this.deck = deck;
        return this;
    }

    public Game build(){
        //return new Game(players, deck);
        return null;
    }
}
