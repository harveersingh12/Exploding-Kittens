package Utils;

import Model.CardType;

import java.util.ArrayList;
import java.util.HashSet;

class RemovedCodes {

    //FROM CLASS CARD

//    private String setName(CardType type){
//        ArrayList<String> names = createName(type);
//        int index;
//        do {
//            index = (int) (Math.random() * names.size());
//            name = names.get(index);
//        } while (usedNames.contains(name) && !name.contains(type.name().toLowerCase()));
//
//        String localName = names.get(index);
//        usedNames.add(localName);
//        return localName;
//    }
//
//    public HashSet<String> getUsedNames(){
//        return usedNames;
//    }
//
//    /**
//     * @param type is the type of each card in the list of card names
//     * @return the list of all cards of a single type
//     **/
//    public ArrayList<String> createName (CardType type){
//        ArrayList<String> names = new ArrayList<>();
////        switch(type){
//            case NOPE:
//                Collections.addAll(names, "nope1", "nope2", "nope3", "nope4", "nope5");
//                break;
//            case SKIP:
//                Collections.addAll(names, "skip1", "skip2", "skip3", "skip4");
//                break;
//            case FAVOR:
//                Collections.addAll(names, "favor1", "favor2", "favor3", "favor4");
//                break;
//            case SHUFFLE:
//                Collections.addAll(names, "shuffle1", "shuffle2", "shuffle3", "shuffle4");
//                break;
//            case SEE_THE_FUTURE:
//                Collections.addAll(names, "stf1", "stf2", "stf3", "stf4", "stf5");
//                break;
//            case ATTACK:
//                Collections.addAll(names, "attack1", "attack2", "attack3", "attack4");
//                break;
//            case HAIRY_POTATO:
//                Collections.addAll(names, "potato1", "potato2", "potato3", "potato4");
//                break;
//            case TACO_CAT:
//                Collections.addAll(names, "taco1", "taco2", "taco3", "taco4");
//                break;
//            case RAINBOW_RALPHING:
//                Collections.addAll(names, "rr1", "rr2", "rr3", "rr4", "rr5");
//                break;
//            case BEARD_CAT:
//                Collections.addAll(names, "beard1", "beard2", "beard3", "beard4");
//                break;
//            case CATTERMELON:
//                Collections.addAll(names, "melon1", "melon2", "melon3", "melon4");
//                break;
//            case EXPLODING_KITTEN:
//                Collections.addAll(names, "ek1", "ek2", "ek3", "ek4");
//                break;
//            case DEFUSE:
//                Collections.addAll(names, "defuse1", "defuse2", "defuse3", "defuse4", "defuse5", "defuse6");
//                break;
//        }
//        return names;
//}


//    private void listGenerator(int position_amount){
//        for(int i = 0; i< CardType.values().length; i++){
//            for(int j = 0; j<CardType.values()[i].getAmount().get(position_amount); j++){
//                String name = CardType.values()[i].name().toLowerCase() + String.valueOf(j);
//                System.out.println(name);
//                if(usedNames == null || !usedNames.contains(name))
//                    names.add(name);
//            }
//        }
    }

    /*
    private int askForIndex(String currentPlayerName){
        for (int i=0; i<playerNames.size(); i++)
            if(!playerNames.get(i).equals(currentPlayerName)) view.update((i+1)+". " + playerNames.get(i));

        int index=view.keyboardIntInput();

        while(index < 0 || index > playerNames.size()-1||playerNames.get(index).equals(currentPlayerName)){
            view.update("Please enter a valid index which is not yours. The players of the game are: ");
            for (int i=0; i<playerNames.size(); i++)
                if(!playerNames.get(i).equals(currentPlayerName)) view.update((i+1)+". "+playerNames.get(i));
            index=view.keyboardIntInput()-1;
        }
        return index;
    }
*/

//        int favorPlayerIndex=askForIndex(currentPlayerName);
//
//        Player favorPlayer=null;
//        for (Player checkThisPlayer : players) {
//            if(checkThisPlayer.getName().equals(playerNames.get(favorPlayerIndex))) {
//                favorPlayer=checkThisPlayer;
//                break;
//            }
//        }