package View;

import java.net.InetAddress;
import java.util.Scanner;

public class GameTUI implements UserInterface{

    @Override
    public void update(String message){
        System.out.println(message);
    }

    @Override
    public String keyboardStringInput(){
        Scanner stringScanner = new Scanner(System.in);
        return stringScanner.nextLine();
    }

    @Override
    public int keyboardIntInput(){
        Scanner intScanner = new Scanner(System.in);
        int number = intScanner.nextInt();
        intScanner.nextLine();
        return number;
    }

    @Override
    public void showError(String message){
        System.out.println("\u001B[31m" + message + "\u001B[0m");
    }

    @Override
    public void updateSameLine(String message){
        System.out.print(message);
    }
}
