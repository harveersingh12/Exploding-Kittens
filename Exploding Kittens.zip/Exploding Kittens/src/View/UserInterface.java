package View;

import java.net.InetAddress;

public interface UserInterface {
    void update(String message);
    String keyboardStringInput();
    int keyboardIntInput();
    void showError(String message);
    void updateSameLine(String message);
}
